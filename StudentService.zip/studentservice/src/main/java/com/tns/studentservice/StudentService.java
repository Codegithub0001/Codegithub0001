package com.tns.studentservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class StudentService {
    
    @Autowired
    private StudentRepository repository;

    public List<Students> getAllStudents() {
        return repository.findAll();
    }

    public Students getStudent(Long id) {
        Optional<Students> student = repository.findById(id);
        return student.orElse(null);
    }

    public Students createStudent(Students student) {
        return repository.save(student);
    }

    public Students updateStudent(Long id, Students student) {
        if (repository.existsById(id)) {
            student.setId(id);
            return repository.save(student);
        }
        return null;
    }

    public void deleteStudent(Long id) {
        repository.deleteById(id);
    }

    public Students getStudentByRollNumber(String rollNumber) {
        return repository.findByRollNumber(rollNumber).orElse(null);
    }

    public List<Students> getStudentsByDepartment(String department) {
        return repository.findByDepartment(department);
    }

    public List<Students> getStudentsBySemester(int semester) {
        return repository.findBySemester(semester);
    }

    public List<Students> getStudentsByDepartmentAndSemester(String department, int semester) {
        return repository.findByDepartmentAndSemester(department, semester);
    }
}
