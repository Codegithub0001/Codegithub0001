package com.tns.studentservice;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepository extends JpaRepository<Students, Long> {
    Optional<Students> findByRollNumber(String rollNumber);
    List<Students> findByDepartment(String department);
    List<Students> findBySemester(int semester);
    List<Students> findByDepartmentAndSemester(String department, int semester);
}
